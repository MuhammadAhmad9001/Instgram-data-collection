
from .models import contactus

def get_all_contacted_details():
    return contactus.objects.all()

# def dele_contacted(self):
 #   namee = input("give name which you want to del")
  #  del namee
        

def del_contacted(name):
    contactus.object.filter(name=name).delete()

def update_contact(name,email):
    contactus.object.filter(name=name).update()
    contactus.object.filter(email=email).update()
    