from django.db import models
import datetime
from datetime import date
from django.utils import timezone
# Create your models here.

class contactus(models.Model):
    
    Your_name = models.CharField(max_length=30)
    Email = models.CharField(max_length=30)
    Message = models.CharField(max_length=300)
   
    def __str__(self):
        return self.Your_name