from django.contrib import admin

# Register your models here.
from .model import contactus

admin.site.register(contactus)


